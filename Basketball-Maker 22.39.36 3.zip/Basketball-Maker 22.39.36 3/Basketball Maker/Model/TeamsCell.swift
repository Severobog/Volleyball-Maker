//
//  TeamsCell.swift
//  Basketball Maker
//
//  Created by Демид Стариков on 07.09.2022.
//

import UIKit

class TeamsCell: UITableViewCell {
    
    @IBOutlet var flagImg: UIImageView!
    @IBOutlet var teamLbl: UILabel!
    @IBOutlet var fwdImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
