//
//  FormationCell.swift
//  Basketball Maker
//
//  Created by Демид Стариков on 07.09.2022.
//

import UIKit

class FormationCell: UITableViewCell {

    @IBOutlet var label: UILabel!
    @IBOutlet var forwardImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }


}
